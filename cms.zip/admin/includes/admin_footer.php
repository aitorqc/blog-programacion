   <!-- jQuery -->
   <script src="js/jquery.js"></script>
   <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

   <!-- Bootstrap Core JavaScript -->
   <script src="js/bootstrap.min.js"></script>

   <!-- include summernote css/js -->
   <script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.js"></script>

   <script src="js/scripts.js"></script>
   <script src="js/update_user_activity.js"></script>

   </body>

   </html>

   <?php session_write_close(); ?>