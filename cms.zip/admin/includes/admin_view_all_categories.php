<table class="table table-bordered table-hover">
    <thead>
        <tr>
            <th>Id</th>
            <th>Categoría</th>
            <th></th>
            <th></th>
        </tr>
    </thead>
    <tbody>
        <?php
        show_categories();
        ?>
    </tbody>
</table>